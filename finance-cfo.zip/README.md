# Finance CFO - Hackathon MVP

This repository contains a minimal full-stack scaffold for the "Finance CFO" project (MVP).
The stack:
- Backend: FastAPI (Python)
- Database: PostgreSQL
- Frontend: React (create-react-app)
- Local orchestration: docker-compose

## What I created for you
- A runnable MVP with:
  - CSV transaction upload endpoint
  - Projection simulator endpoint (SIP future value)
  - Simple React UI with simulator and chat placeholder

## How to run locally (Linux / Mac / Windows with Docker)
1. Clone your repo locally.
2. Copy `.env.example` to `.env` in `backend/` and customize if needed.
3. Run:
   ```bash
   docker-compose up --build
   ```
4. Frontend will be on http://localhost:3000 and backend on http://localhost:8000/api

## How to push these files to your GitHub repo
After downloading the provided zip and extracting into your local clone, run:
```bash
git add .
git commit -m "Add MVP scaffold (FastAPI + React)"
git push origin main
```

## Next steps (suggested)
- Implement secure OAuth connectors or aggregator for bank APIs.
- Add deterministic net-worth endpoint and populate DB from CSV uploads.
- Add proper auth (OAuth2) and HTTPS for production.
- Plug in an LLM provider if you want richer natural-language responses.
