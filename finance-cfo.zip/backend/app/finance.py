def emi(principal: float, annual_rate_percent: float, months: int) -> float:
    if principal == 0 or months == 0:
        return 0.0
    r = (annual_rate_percent / 100.0) / 12.0
    num = principal * r * ((1 + r) ** months)
    den = ((1 + r) ** months) - 1
    return num / den

def future_value_sip(monthly: float, annual_rate_percent: float, years: int) -> float:
    i = (annual_rate_percent / 100.0) / 12.0
    n = years * 12
    if i == 0:
        return monthly * n
    fv = monthly * (((1 + i) ** n - 1) / i)
    return fv
