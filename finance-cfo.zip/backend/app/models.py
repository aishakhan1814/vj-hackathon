from sqlalchemy import Column, Integer, String, Float, ForeignKey
from sqlalchemy.orm import relationship
from db import Base
from sqlalchemy.types import JSON

class Account(Base):
    __tablename__ = "accounts"
    id = Column(Integer, primary_key=True, index=True)
    provider = Column(String, nullable=True)
    account_type = Column(String)
    currency = Column(String, default="INR")
    balance = Column(Float, default=0.0)
    meta = Column(JSON, nullable=True)

class Transaction(Base):
    __tablename__ = "transactions"
    id = Column(Integer, primary_key=True, index=True)
    account_id = Column(Integer, ForeignKey("accounts.id"))
    date = Column(String)
    amount = Column(Float)
    description = Column(String)
    category = Column(String)
    account = relationship("Account")

class Holding(Base):
    __tablename__ = "holdings"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String)
    quantity = Column(Float)
    avg_price = Column(Float)
    current_price = Column(Float)
    currency = Column(String, default="INR")

class Loan(Base):
    id = Column(Integer, primary_key=True, index=True)
    lender = Column(String)
    principal = Column(Float)
    outstanding = Column(Float)
    interest_rate = Column(Float)  # annual perc
    tenure_months = Column(Integer)
