from pydantic import BaseModel
from typing import Optional, List

class UploadResponse(BaseModel):
    message: str

class NetWorthResponse(BaseModel):
    total_assets: float
    total_liabilities: float
    net_worth: float

class SimulateRequest(BaseModel):
    monthly_investment: float
    annual_return: float
    years: int

class SimulateResponse(BaseModel):
    future_value: float
    inputs: dict
