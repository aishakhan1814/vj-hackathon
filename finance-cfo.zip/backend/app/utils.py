import pandas as pd
from models import Account, Transaction, Holding, Loan
from db import SessionLocal

def parse_csv_transactions(fileobj):
    # Basic CSV ingestion using pandas
    df = pd.read_csv(fileobj)
    # Expected columns: date, amount, description, account (account optional)
    rows = df.to_dict(orient="records")
    return rows

def save_transactions(rows):
    db = SessionLocal()
    added = 0
    for r in rows:
        acct_name = r.get("account") or "uploaded"
        acct = db.query(Account).filter_by(provider=acct_name).first()
        if not acct:
            acct = Account(provider=acct_name, account_type="bank", balance=0.0)
            db.add(acct)
            db.commit()
            db.refresh(acct)
        txn = Transaction(
            account_id=acct.id,
            date=str(r.get("date")),
            amount=float(r.get("amount") or 0.0),
            description=r.get("description") or "",
            category=r.get("category") or None
        )
        db.add(txn)
        added += 1
    db.commit()
    db.close()
    return added
