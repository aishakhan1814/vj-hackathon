from fastapi import APIRouter, UploadFile, File
from fastapi.responses import JSONResponse
from schemas import UploadResponse, NetWorthResponse, SimulateRequest, SimulateResponse
from utils import parse_csv_transactions, save_transactions
from finance import emi, future_value_sip
from db import SessionLocal, init_db

router = APIRouter()

@router.on_event("startup")
def startup():
    init_db()

@router.post("/upload/transactions", response_model=UploadResponse)
async def upload_transactions(file: UploadFile = File(...)):
    contents = await file.read()
    import io
    rows = parse_csv_transactions(io.BytesIO(contents))
    added = save_transactions(rows)
    return UploadResponse(message=f"Saved {added} transactions")

@router.get("/networth", response_model=NetWorthResponse)
def net_worth():
    db = SessionLocal()
    total_assets = 0.0
    total_liabilities = 0.0
    # TODO: implement actual sums from DB (MVP placeholders)
    return NetWorthResponse(total_assets=total_assets, total_liabilities=total_liabilities, net_worth=total_assets - total_liabilities)

@router.post("/simulate", response_model=SimulateResponse)
def simulate(req: SimulateRequest):
    fv = future_value_sip(req.monthly_investment, req.annual_return, req.years)
    return SimulateResponse(future_value=round(fv,2), inputs=req.dict())
