import React from 'react';
import Dashboard from './components/Dashboard';
import Chat from './components/Chat';

function App(){
  return (
    <div className="app">
      <header>
        <h1>Finance CFO (MVP)</h1>
      </header>
      <main>
        <Dashboard />
        <Chat />
      </main>
    </div>
  );
}

export default App;
