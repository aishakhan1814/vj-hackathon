import React, {useState} from 'react';

export default function Chat(){
  const [q, setQ] = useState('');
  const [out, setOut] = useState(null);

  async function ask(){
    if(q.toLowerCase().includes('savings')){
      setOut('Try saving at least 20% of your income. Use the simulator to check outcomes.');
    } else {
      setOut('Ask about projections or upload transactions to get personalized answers.');
    }
  }

  return (
    <div className="card">
      <h2>Chat (MVP)</h2>
      <input value={q} onChange={e=>setQ(e.target.value)} placeholder="Ask: Can I afford a 50L home?" />
      <button onClick={ask}>Ask</button>
      {out && <div className="answer">{out}</div>}
    </div>
  );
}
