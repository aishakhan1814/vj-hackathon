import React, {useState} from 'react';
import {simulate} from '../api';

export default function Dashboard(){
  const [monthly, setMonthly] = useState(10000);
  const [years, setYears] = useState(10);
  const [rate, setRate] = useState(8);
  const [result, setResult] = useState(null);

  async function runSim(){
    const r = await simulate({monthly_investment: Number(monthly), annual_return: Number(rate), years: Number(years)});
    setResult(r);
  }

  return (
    <div className="card">
      <h2>Projection Simulator</h2>
      <label>Monthly investment (₹)</label>
      <input value={monthly} onChange={e=>setMonthly(e.target.value)} />
      <label>Years</label>
      <input value={years} onChange={e=>setYears(e.target.value)} />
      <label>Expected annual return (%)</label>
      <input value={rate} onChange={e=>setRate(e.target.value)} />
      <button onClick={runSim}>Simulate</button>
      {result && (
        <div>
          <h3>Future value: ₹{result.future_value}</h3>
          <pre>{JSON.stringify(result.inputs, null, 2)}</pre>
        </div>
      )}
    </div>
  );
}
