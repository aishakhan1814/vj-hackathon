import axios from 'axios';
const API = axios.create({
  baseURL: process.env.REACT_APP_API_URL || "http://localhost:8000/api",
});

export async function simulate(data){
  const r = await API.post('/simulate', data);
  return r.data;
}

export async function uploadTransactions(file){
  const form = new FormData();
  form.append('file', file);
  const r = await API.post('/upload/transactions', form, {
    headers: {'Content-Type': 'multipart/form-data'}
  });
  return r.data;
}
